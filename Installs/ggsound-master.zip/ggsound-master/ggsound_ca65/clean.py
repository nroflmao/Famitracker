import os

os.system("build.py clean")
